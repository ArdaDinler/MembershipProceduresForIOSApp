//
//  Person.m
//  sqlTutorial
//
//  Created by Arda Dinler on 8/11/15.
//  Copyright (c) 2015 Arda dinler. All rights reserved.
//

#import "Person.h"

@implementation Person

@end
