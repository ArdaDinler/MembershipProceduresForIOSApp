//
//  VerificationViewController.h
//  sqlTutorial
//
//  Created by Arda Dinler on 8/12/15.
//  Copyright (c) 2015 Arda dinler. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import "SKPSMTPMessage.h"
#import "NSData+Base64Additions.h"
#import "TextFieldValidator.h"
#import "Person.h"
#import "sqlite3.h"

#define REGEX_CODE_LIMIT @"^.{3,10}$"
#define REGEX_CODE @"[A-Za-z0-9]{3,10}"

@interface VerificationViewController : UIViewController<SKPSMTPMessageDelegate,UIScrollViewDelegate,UITextFieldDelegate>
{
    //MFMailComposeViewControllerDelegate
    sqlite3 *personDB;
    NSString *dbPathString;
    IBOutlet TextFieldValidator *txtKod;
    BOOL isReSendMail;
    
}
@property (nonatomic)NSString *Id;
@property (nonatomic)NSString *name;
@property (nonatomic)NSString *surname;
@property (nonatomic)NSString *pass;
@property (nonatomic)NSString *mail;
@property (nonatomic)NSString *phone;
@property (nonatomic)NSString *activityCode;

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

-(BOOL)isValidTextField;
-(void)dismissKeyboard;
-(void)createOrOpenDB;
- (void)addPerson;
-(void)updatePersonActvtyCode;
-(void)setupAlerts;
-(NSString *)getUUID;
-(NSString *)getCode;
- (NSString * )displayPerson;
//-(void)sendMail:(NSString *)personEmail;
-(void) sendEmailInBackground:(NSString *)personEmail:(SKPSMTPMessage *)msj;
- (IBAction)btnClick:(id)sender;


@end
