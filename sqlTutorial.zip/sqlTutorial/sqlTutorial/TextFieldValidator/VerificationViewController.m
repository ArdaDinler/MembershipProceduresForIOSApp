//
//  VerificationViewController.m
//  sqlTutorial
//
//  Created by Arda Dinler on 8/12/15.
//  Copyright (c) 2015 Arda dinler. All rights reserved.
//

#import "VerificationViewController.h"


@interface VerificationViewController ()

@end

@implementation VerificationViewController

@synthesize name,surname,pass,mail,phone,activityCode;


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setupAlerts];
    [self createOrOpenDB];
    
    isReSendMail=NO;
    
    txtKod.presentInView = self.view;
    txtKod.delegate=self;

    UIBarButtonItem *myBarButton = [[UIBarButtonItem alloc] initWithTitle:@"ReSendMail" style:UIBarButtonItemStyleDone target:self action:@selector(ReSendbuttonAction:)];
    
    self.navigationItem.rightBarButtonItems = @[myBarButton];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(dismissKeyboard)];
    
    [self.view addGestureRecognizer:tap];
    
    
	// Do any additional setup after loading the view.
}
-(void)dismissKeyboard {
    [txtKod resignFirstResponder];
}
-(void)ReSendbuttonAction:(id)sender
{
    //[self sendMail:self.mail];
    NSString *mailStatic=self.mail ;
    NSLog(@"%@",self.mail);
    self.activityCode = self.getCode;
    isReSendMail=YES;
    NSString *activityCodeStatic=self.activityCode ;
    
    SKPSMTPMessage *msj=[[SKPSMTPMessage alloc] init];
    SKPSMTPMessage *staticMsj = msj;
    dispatch_queue_t mailQueue = dispatch_queue_create("Mail downnloader2", NULL);
    dispatch_async(mailQueue,^{
        @try
        {
            
            [self sendEmailInBackground:mailStatic:staticMsj];
            
            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               //code to be executed on the main thread when background task is finished
                               @try
                               {
                                   
                                   sqlite3_stmt* stmt;
                                   int rc=0;
                                   rc = sqlite3_open_v2([dbPathString UTF8String], &personDB, SQLITE_OPEN_READWRITE , NULL);
                                   
                                   if (SQLITE_OK != rc)
                                   {
                                       sqlite3_close(personDB);
                                       NSLog(@"Failed to open db connection");
                                   }
                                   else
                                   {
                                       self.activityCode = self.getCode;
                                       NSString  * query = [NSString stringWithFormat:@"UPDATE person SET ACTVTYCODE='%@' WHERE ID LIKE '%@'",activityCodeStatic,self.Id];
                                       rc =sqlite3_prepare_v2(personDB,[query UTF8String], -1, &stmt, NULL);
                                       if(rc == SQLITE_OK)
                                       {
                                           char * errMsg;
                                           rc = sqlite3_exec(personDB, [query UTF8String] ,NULL,NULL,&errMsg);
                                           if(SQLITE_OK != rc)
                                           {
                                               NSLog(@"Failed to insert record rc:%d, msg=%s",rc,errMsg);
                                           }
                                           NSLog(@"Basarili Kod Degisimi");
                                           sqlite3_finalize(stmt);
                                       }
                                       else
                                       {
                                           NSLog(@"Failed to prepare statement with rc:%d",rc);
                                       }
                                       sqlite3_close(personDB);
                                   }
                                   
                               }
                               @catch (NSException *exception)
                               {
                                   
                               }
                           });
        }
        @catch (NSException *exception)
        {
            
        }
    });

}
-(void)setupAlerts{
    [txtKod addRegx:REGEX_CODE_LIMIT withMsg:@"Code charaters limit should be come between 3-10"];
    [txtKod addRegx:REGEX_CODE withMsg:@"Only alpha numeric characters are allowed."];
    //self->txtKod.validateOnResign=NO;
}
-(BOOL)isValidTextField
{
    if([self->txtKod validate]){
        return YES;
    }
    return NO;
}
-(void)createOrOpenDB
{
    //baglantı ayarları
    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath = [path objectAtIndex:0];
    dbPathString = [docPath stringByAppendingPathComponent:@"person.db"];
    
    int rc=0;
    rc = sqlite3_open_v2([dbPathString cStringUsingEncoding:NSUTF8StringEncoding], &personDB, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE, NULL);
    if (SQLITE_OK != rc)
    {
        sqlite3_close(personDB);
        NSLog(@"Failed to open db connection");
    }
    else
    {
        char * query ="CREATE TABLE IF NOT EXISTS person ( ID TEXT PRIMARY KEY, NAME  TEXT, SURNAME  TEXT,PASSWORD  TEXT,MAIL  TEXT,PHONE  TEXT,ACTVTYCODE TEXT,ACTIVE INTEGER)";
        char * errMsg;
        rc = sqlite3_exec(personDB, query,NULL,NULL,&errMsg);
        
        if(SQLITE_OK != rc)
        {
            NSLog(@"Failed to create table rc:%d, msg=%s",rc,errMsg);
        }
        
        sqlite3_close(personDB);
    }
}
- (void)addPerson
{
    int rc=0;
    rc = sqlite3_open_v2([dbPathString cStringUsingEncoding:NSUTF8StringEncoding], &personDB, SQLITE_OPEN_READWRITE , NULL);
    if (SQLITE_OK != rc)
    {
        sqlite3_close(personDB);
        NSLog(@"Failed to open db connection");
    }
    else
    {
        self.Id=[self getUUID];
        NSString * query  = [NSString stringWithFormat:@"INSERT INTO person (ID,NAME,SURNAME,PASSWORD,MAIL,PHONE,ACTVTYCODE,ACTIVE) VALUES (\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",%d)",[self.Id UTF8String],[self.name UTF8String],[self.surname UTF8String],[self.pass UTF8String],[self.mail UTF8String],[self.phone UTF8String],[self.activityCode UTF8String],0];
        char * errMsg;
        rc = sqlite3_exec(personDB, [query UTF8String] ,NULL,NULL,&errMsg);
        if(SQLITE_OK != rc)
        {
            NSLog(@"Failed to insert record fdg rc:%d, msg=%s",rc,errMsg);
        }
        sqlite3_close(personDB);
    }
}
-(void)updatePersonActvtyCode
{
    
}
- (NSString *)displayPerson
{
    sqlite3_stmt* stmt =NULL;
    NSString *actCode;
    int rc=0;
    rc = sqlite3_open_v2([dbPathString UTF8String], &personDB, SQLITE_OPEN_READONLY , NULL);
    
    if (SQLITE_OK != rc)
    {
        sqlite3_close(personDB);
        NSLog(@"Failed to open db connection");
    }
    else
    {
        NSString  * query = [NSString stringWithFormat:@"SELECT * from person WHERE ID LIKE '%@'", self.Id];
        
        rc =sqlite3_prepare_v2(personDB, [query UTF8String], -1, &stmt, NULL);
        if(rc == SQLITE_OK)
        {
            while (sqlite3_step(stmt) == SQLITE_ROW) //get each row in loop
            {
                self.Id=[NSString stringWithUTF8String:(const char *)sqlite3_column_text(stmt, 0)];
                self.name =[NSString stringWithUTF8String:(const char *)sqlite3_column_text(stmt, 1)];
                self.surname = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(stmt, 2)];
                self.pass=[NSString stringWithUTF8String:(const char *)sqlite3_column_text(stmt, 3)];
                self.mail=[NSString stringWithUTF8String:(const char *)sqlite3_column_text(stmt, 4)];
                self.phone=[NSString stringWithUTF8String:(const char *)sqlite3_column_text(stmt, 5)];
                actCode =  [NSString stringWithUTF8String:(const char *)sqlite3_column_text(stmt, 6)];

                NSLog(@"act=%@",actCode);
                
            }
            NSLog(@"Done");
            sqlite3_finalize(stmt);
        }
        else
        {
            NSLog(@"Failed to prepare statement with rc:%d",rc);
        }
        sqlite3_close(personDB);
    }
    return actCode;
}

-(void) sendEmailInBackground:(NSString *)personEmail:(SKPSMTPMessage *)emailMessage
{
    NSLog(@"Start Sending");
    if(!isReSendMail){
        self.activityCode=self.getCode;
    }
    else
    {
        [self displayPerson];
    }
    NSLog(@"%@",personEmail);
    NSLog(@"%@",self.name);
    NSLog(@"%@",self.surname);
    NSString *mailBody = [NSString stringWithFormat:@"Name:%@ \n Surname:%@ \n Password:%@ \n Mail:%@ \n Phone:%@ \n Verification Code:%@",self.name,self.surname,self.pass,self.mail,self.phone,self.activityCode];
    emailMessage.fromEmail = @"ardadinler100@gmail.com"; //sender email address
    emailMessage.toEmail = personEmail;  //receiver email address
    emailMessage.relayHost = @"smtp.gmail.com";
    //emailMessage.ccEmail =@"your cc address";
    //emailMessage.bccEmail =@"your bcc address";
    emailMessage.requiresAuth = YES;
    emailMessage.login = @"ardadinler100@gmail.com"; //sender email address
    emailMessage.pass = @"arda5dinler390"; //sender email password
    emailMessage.subject =@"Sign Up Verification";
    emailMessage.wantsSecure = YES;
    emailMessage.delegate = self; // you must include <SKPSMTPMessageDelegate> to your class
    NSString *messageBody = mailBody;
    // Now creating plain text email message
    NSDictionary *plainMsg = [NSDictionary
                              dictionaryWithObjectsAndKeys:@"text/plain",kSKPSMTPPartContentTypeKey,
                              messageBody,kSKPSMTPPartMessageKey,@"8bit",kSKPSMTPPartContentTransferEncodingKey,nil];
    emailMessage.parts = [NSArray arrayWithObjects:plainMsg,nil];
    //in addition : Logic for attaching file with email message.
    /*
     NSString *filePath = [[NSBundle mainBundle] pathForResource:@"filename" ofType:@"JPG"];
     NSData *fileData = [NSData dataWithContentsOfFile:filePath];
     NSDictionary *fileMsg = [NSDictionary dictionaryWithObjectsAndKeys:@"text/directory;\r\n\tx-
     unix-mode=0644;\r\n\tname=\"filename.JPG\"",kSKPSMTPPartContentTypeKey,@"attachment;\r\n\tfilename=\"filename.JPG\"",kSKPSMTPPartContentDispositionKey,[fileData encodeBase64ForData],kSKPSMTPPartMessageKey,@"base64",kSKPSMTPPartContentTransferEncodingKey,nil];
     emailMessage.parts = [NSArray arrayWithObjects:plainMsg,fileMsg,nil]; //including plain msg and attached file msg
     */
    [emailMessage send];
    // sending email- will take little time to send so its better to use indicator with message showing sending...
}

//Now, handling delegate methods :
// On success

-(void)messageSent:(SKPSMTPMessage *)message{
    NSLog(@"delegate - message sent");
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message is your mailbox!" message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    [alert show];
}
// On Failure
-(void)messageFailed:(SKPSMTPMessage *)message error:(NSError *)error{
    // open an alert with just an OK button
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    [alert show];
    NSLog(@"delegate - error(%ld): %@", (long)[error code], [error localizedDescription]);
}
/*
 -(void)sendMail:(NSString *)personEmail
 {
 if ([MFMailComposeViewController canSendMail])
 {
 MFMailComposeViewController *mailController = [[MFMailComposeViewController alloc]init];
 mailController.mailComposeDelegate = self;
 NSString *mailBody = [NSString stringWithFormat:@"Name:%@ \n Surname:%@ \n Password:%@ \n Mail:%@ \n Phone:%@ \n Verification Code:%@",self.name,self.surname,self.pass,self.mail,self.phone,self.getCode];
 NSArray *mailArray = [[NSArray alloc]initWithObjects:personEmail, nil];
 [mailController setToRecipients:mailArray];
 [mailController setSubject:@"Sign Up Verification"];
 [mailController setMessageBody:mailBody isHTML:NO ];
 [self presentViewController:mailController animated:YES completion:nil];
 }
 else
 NSLog(@"This device cannot send email");
 }
 -(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
 {
 switch (result)
 {
 case MFMailComposeResultCancelled:
 //NSLog(@"Result: canceled");
 break;
 case MFMailComposeResultSaved:
 //NSLog(@"Result: saved");
 break;
 case MFMailComposeResultSent:
 {
 controller.
 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Result" message:@"Mail Sent Successfully" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
 [alert show];
 //controller.delegate=nil;
 }
 break;
 case MFMailComposeResultFailed:
 //NSLog(@"Result: failed");
 break;
 default:
 //NSLog(@"Result: not sent");
 break;
 }
 [self dismissViewControllerAnimated:YES completion:nil];
 }
 */
- (IBAction)btnClick:(id)sender {
    NSLog(@"%@",self.displayPerson);
    NSLog(@"%d",[self isValidTextField]);
    if([self isValidTextField])
    {
        if([self.displayPerson isEqualToString:txtKod.text])
        {
            
            sqlite3_stmt* stmt;
            int rc=0;
            rc = sqlite3_open_v2([dbPathString UTF8String], &personDB, SQLITE_OPEN_READWRITE , NULL);
            
            if (SQLITE_OK != rc)
            {
                sqlite3_close(personDB);
                NSLog(@"Failed to open db connection");
            }
            else
            {
                NSInteger act=1;
                NSString  * query = [NSString stringWithFormat:@"UPDATE person SET ACTIVE=%d WHERE ID LIKE '%@'",act,self.Id];
                rc =sqlite3_prepare_v2(personDB,[query UTF8String], -1, &stmt, NULL);
                if(rc == SQLITE_OK)
                {
                    char * errMsg;
                    rc = sqlite3_exec(personDB, [query UTF8String] ,NULL,NULL,&errMsg);
                    if(SQLITE_OK != rc)
                    {
                        NSLog(@"Failed to insert record  rc:%d, msg=%s",rc,errMsg);
                    }
                    NSLog(@"Basarili");
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Dogrulama işleminiz bitmiştir!" message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
                    [alert show];
                    sqlite3_finalize(stmt);
                }
                else
                {
                    NSLog(@"Failed to prepare statement with rc:%d",rc);
                }
                sqlite3_close(personDB);
            }
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Dogrulama kodunuz yalnistir!" message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
            [alert show];
        }
    }
}

//Random olarak stringler üreten kodlar

-(NSString *)getUUID
{
    NSString *uuidString = [[NSProcessInfo processInfo] globallyUniqueString];
    return uuidString;
}
-(NSString *)getCode
{
    NSString *alphabet  = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXZY0123456789";
    NSMutableString *s = [NSMutableString stringWithCapacity:6];
    for (NSUInteger i = 0; i < 6; i++) {
        u_int32_t r = arc4random() % [alphabet length];
        unichar c = [alphabet characterAtIndex:r];
        [s appendFormat:@"%C", c];
    }
    return s;
}
@end
