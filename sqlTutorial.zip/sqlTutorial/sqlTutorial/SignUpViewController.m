//
//  SignUpViewController.m
//  sqlTutorial
//
//  Created by Arda Dinler on 8/12/15.
//  Copyright (c) 2015 Arda dinler. All rights reserved.
//

#import "SignUpViewController.h"

@interface SignUpViewController ()
{
    VerificationViewController *verificationViewController;
}
@end


@implementation SignUpViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setupAlerts];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(dismissKeyboard)];
    
    [self.view addGestureRecognizer:tap];
    
    //Navigation bar button'u ile subview geçiş için myBarButton ' un oluşturulması
    /*
     UIBarButtonItem *myBarButton = [[UIBarButtonItem alloc] initWithTitle:@"SignUp" style:UIBarButtonItemStyleDone target:self action:@selector(buttonAction:)];
     
     self.navigationItem.rightBarButtonItems = @[myBarButton];
     */
    
    //self.scrollView.minimumZoomScale =0.2 ;
    //self.scrollView.maximumZoomScale =5;
    
    
}
-(void)dealloc
{
    self.scrollView.delegate =nil;
}
- (void)registerForKeyboardNotifications {
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    
}

- (void)deregisterFromKeyboardNotifications {
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardDidHideNotification
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardWillHideNotification
                                                  object:nil];
    
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    [self registerForKeyboardNotifications];
    
}

- (void)viewWillDisappear:(BOOL)animated {
    
    [self deregisterFromKeyboardNotifications];
    
    [super viewWillDisappear:animated];
    
}
- (void)keyboardWasShown:(NSNotification *)notification {
    
    if(!txtUserName.isEditing && !txtSurname.isEditing && !txtPassword.isEditing){
        NSDictionary* info = [notification userInfo];
        
        CGSize keyboardSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
        
        CGPoint buttonOrigin = signUpButton.frame.origin;
        
        CGFloat buttonHeight = signUpButton.frame.size.height;
        
        CGRect visibleRect = self.view.frame;
        
        visibleRect.size.height -= keyboardSize.height;
        
        if (!CGRectContainsPoint(visibleRect, buttonOrigin)){
            
            CGPoint scrollPoint = CGPointMake(0.0, buttonOrigin.y - visibleRect.size.height + buttonHeight);
            
            [self.scrollView setContentOffset:scrollPoint animated:YES];
            
        }
    }
    
}

- (void)keyboardWillBeHidden:(NSNotification *)notification {
    
    [self.scrollView setContentOffset:CGPointZero animated:YES];
    
}
-(void)dismissKeyboard {
    [self->txtUserName resignFirstResponder];
    [self->txtSurname resignFirstResponder];
    [self->txtEmail resignFirstResponder];
    [self->txtPassword resignFirstResponder];
    [self->txtConfirmPass resignFirstResponder];
    [self->txtPhone resignFirstResponder];
}

//Navigation bar button'u ile subview geçiş için myBarButton action ' ın implementasyonu

/*
 -(void)buttonAction:(id)sender
 {
 if([txtUserName validate] & [txtEmail validate] & [txtPassword validate] & [txtConfirmPass validate] & [txtPhone validate] & [txtSurname validate]){
 verificationViewController=[[UIStoryboard storyboardWithName:@"MainStoryboard" bundle:nil] instantiateViewControllerWithIdentifier:@"VerificationViewController"];
 [self.navigationController pushViewController:verificationViewController animated:YES];
 }
 }
 */


//Kalvye kapanması için bir diğer kod
/*
 -(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
 {
 [self.scrollView touchesBegan:touches withEvent:event];
 [txtUserName resignFirstResponder];
 [txtSurname resignFirstResponder];
 [txtEmail resignFirstResponder];
 [txtPassword resignFirstResponder];
 [txtConfirmPass resignFirstResponder];
 [txtPhone resignFirstResponder];
 }
 */

//Text field alanlarının error mesajlarının oluşturulması
-(void)setupAlerts{
    [txtUserName addRegx:REGEX_USER_NAME_LIMIT withMsg:@"User name charaters limit should be come between 3-10"];
    [txtUserName addRegx:REGEX_USER_NAME withMsg:@"Only alpha numeric characters are allowed."];
    txtUserName.validateOnResign=NO;
    
    [txtEmail addRegx:REGEX_EMAIL withMsg:@"Enter valid email."];
    
    [txtPassword addRegx:REGEX_PASSWORD_LIMIT withMsg:@"Password characters limit should be come between 6-20"];
    [txtPassword addRegx:REGEX_PASSWORD withMsg:@"Password must contain alpha numeric characters."];
    
    [txtConfirmPass addConfirmValidationTo:txtPassword withMsg:@"Confirm password didn't match."];
    
    [txtPhone addRegx:REGEX_PHONE_DEFAULT withMsg:@"Phone number must be in proper format (eg. ###-###-####)"];
    txtPhone.isMandatory=NO;
}
- (BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender   {
    
    if([identifier isEqualToString:@"ShowIn"])
    {
        if([txtUserName validate] & [txtEmail validate] & [txtPassword validate] & [txtConfirmPass validate] & [txtPhone validate] & [txtSurname validate]){
            return YES;
        }
    }
    return NO;
    
}
-(void)performSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    verificationViewController=[[UIStoryboard storyboardWithName:@"MainStoryboard" bundle:nil] instantiateViewControllerWithIdentifier:@"VerificationViewController"];
    [self.navigationController pushViewController:verificationViewController animated:NO];
    verificationViewController.name = txtUserName.text;
    verificationViewController.surname = txtSurname.text;
    verificationViewController.pass = txtPassword.text;
    verificationViewController.mail = txtEmail.text;
    verificationViewController.phone = txtPhone.text;
    SKPSMTPMessage *msj=[[SKPSMTPMessage alloc] init];
    
    NSString *mail=txtEmail.text ;
    SKPSMTPMessage *staticMsj=msj;
    dispatch_queue_t mailQueue = dispatch_queue_create("Mail downnloader", NULL);
        dispatch_async(mailQueue,^{
        @try
        {
            
            [verificationViewController sendEmailInBackground:mail:staticMsj];

            dispatch_async(dispatch_get_main_queue(), ^
                           {
                               //code to be executed on the main thread when background task is finished
                               @try
                               {
                                   
                                    [verificationViewController addPerson];
                                   
                               }
                               @catch (NSException *exception)
                               {
                                   
                               }
                           });
        }
        @catch (NSException *exception)
        {
            
        }
    });
    
}
- (IBAction)btnSubmit:(id)sender {
    if([self shouldPerformSegueWithIdentifier:@"ShowIn" sender:sender])
    {
        [self performSegueWithIdentifier:@"ShowIn" sender:sender];
    }
    
}


@end
