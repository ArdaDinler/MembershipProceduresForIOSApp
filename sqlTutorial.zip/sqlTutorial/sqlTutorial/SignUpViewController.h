//
//  SignUpViewController.h
//  sqlTutorial
//
//  Created by Arda Dinler on 8/12/15.
//  Copyright (c) 2015 Arda dinler. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TextFieldValidator.h"
#import "VerificationViewController.h"

#define REGEX_USER_NAME_LIMIT @"^.{4,20}$"
#define REGEX_USER_NAME @"[A-Za-z0-9]{4,20}"
#define REGEX_SURNAME @"[A-Za-z0-9]{3,15}"
#define REGEX_EMAIL @"[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
#define REGEX_PASSWORD_LIMIT @"^.{6,20}$"
#define REGEX_PASSWORD @"[A-Za-z0-9]{6,20}"
#define REGEX_PHONE_DEFAULT @"[0-9]{3}\\-[0-9]{3}\\-[0-9]{4}"

@interface SignUpViewController : UIViewController<UIScrollViewDelegate,UITextFieldDelegate>
{
    IBOutlet TextFieldValidator *txtUserName;
    IBOutlet TextFieldValidator *txtSurname;
    IBOutlet TextFieldValidator *txtEmail;
    IBOutlet TextFieldValidator *txtPassword;
    IBOutlet TextFieldValidator *txtConfirmPass;
    IBOutlet TextFieldValidator *txtPhone;
    
    IBOutlet UIButton *signUpButton;
}


@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

- (IBAction)btnSubmit:(id)sender;
- (BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender ;

@end
