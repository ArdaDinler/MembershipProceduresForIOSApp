//
//  Person.h
//  sqlTutorial
//
//  Created by Arda Dinler on 8/11/15.
//  Copyright (c) 2015 Arda dinler. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject


@property (nonatomic,strong)NSString *Id;
@property (nonatomic,strong)NSString *name;
@property (nonatomic,strong)NSString *surname;
@property (nonatomic,strong)NSString *password;
@property (nonatomic,strong)NSString *phone;
@property (nonatomic,strong)NSString *email;
@property (nonatomic)int ActvState;

@end
