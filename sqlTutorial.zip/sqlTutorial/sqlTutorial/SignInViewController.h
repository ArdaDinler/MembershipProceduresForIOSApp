//
//  SignInViewController.h
//  sqlTutorial
//
//  Created by Arda Dinler on 8/17/15.
//  Copyright (c) 2015 Arda dinler. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TextFieldValidator.h"
#import "SignUpViewController.h"
#import "PersonProfileVC.h" 
#import "sqlite3.h"

#undef REGEX_USER_NAME_LIMIT
#undef REGEX_USER_NAME
#define REGEX_USER_NAME_LIMIT @"^.{10,35}$"
#define REGEX_USER_NAME @"[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
#define REGEX_PASSWORD2_LIMIT @"^.{6,20}$"
#define REGEX_PASSWORD2 @"[A-Za-z0-9]{6,20}"

@interface SignInViewController : UIViewController<UITextFieldDelegate,UIScrollViewDelegate>
{
    NSMutableArray *arrayOfPerson;
    sqlite3 *personDB;
    NSString *dbPathString;
}
@property (weak,nonatomic) IBOutlet TextFieldValidator *txtUser;
@property (weak,nonatomic) IBOutlet TextFieldValidator *txtPassword;
@property IBOutlet UIButton *signInButton;


@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

-(void)setupAlerts;
-(Person *)getPerson;
- (void)setPersonArray;
- (IBAction)signInButton:(id)sender;

@end
