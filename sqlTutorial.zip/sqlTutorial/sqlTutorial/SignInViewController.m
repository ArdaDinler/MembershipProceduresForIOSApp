//
//  SignInViewController.m
//  sqlTutorial
//
//  Created by Arda Dinler on 8/17/15.
//  Copyright (c) 2015 Arda dinler. All rights reserved.
//

#import "SignInViewController.h"

@interface SignInViewController ()
{
    SignUpViewController *signUpViewController;
    PersonProfileVC *personProfileViewController;
    VerificationViewController *verificationViewController;
}
@end

@implementation SignInViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setupAlerts];
    [self createOrOpenDB];
    arrayOfPerson = [[NSMutableArray alloc]init];
    [self setPersonArray];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(dismissKeyboard)];
    
    [self.view addGestureRecognizer:tap];
    
    //Navigation bar button'u ile subview geçiş için myBarButton ' un oluşturulması
    
     UIBarButtonItem *myBarButton = [[UIBarButtonItem alloc] initWithTitle:@"SignUp" style:UIBarButtonItemStyleDone target:self action:@selector(buttonAction:)];
     
     self.navigationItem.rightBarButtonItems = @[myBarButton];
     

}
-(void)createOrOpenDB
{
    //baglantı ayarları
    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath = [path objectAtIndex:0];
    dbPathString = [docPath stringByAppendingPathComponent:@"person.db"];
    
    int rc=0;
    rc = sqlite3_open_v2([dbPathString cStringUsingEncoding:NSUTF8StringEncoding], &personDB, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE, NULL);
    if (SQLITE_OK != rc)
    {
        sqlite3_close(personDB);
        NSLog(@"Failed to open db connection");
    }
    else
    {
        char * query ="CREATE TABLE IF NOT EXISTS person ( ID TEXT PRIMARY KEY, NAME  TEXT, SURNAME  TEXT,PASSWORD  TEXT,MAIL  TEXT,PHONE  TEXT,ACTVTYCODE TEXT,ACTIVE INTEGER)";
        char * errMsg;
        rc = sqlite3_exec(personDB, query,NULL,NULL,&errMsg);
        
        if(SQLITE_OK != rc)
        {
            NSLog(@"Failed to create table rc:%d, msg=%s",rc,errMsg);
        }
        
        sqlite3_close(personDB);
    }
}

-(void)viewWillAppear
{
    [self setPersonArray];
    self.txtUser.text = [NSString stringWithFormat:@"Fill in your mail address"];
    self.txtPassword.text = @"Password";
}
- (void)registerForKeyboardNotifications {
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    
}

- (void)deregisterFromKeyboardNotifications {
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardDidHideNotification
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardWillHideNotification
                                                  object:nil];
    
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    [self registerForKeyboardNotifications];
    
}

- (void)viewWillDisappear:(BOOL)animated {
    
    [self deregisterFromKeyboardNotifications];
    
    [super viewWillDisappear:animated];
    
}
- (void)keyboardWasShown:(NSNotification *)notification {
    
    
    NSDictionary* info = [notification userInfo];
    
    CGSize keyboardSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    CGPoint buttonOrigin = self.signInButton.frame.origin;
    
    CGFloat buttonHeight = self.signInButton.frame.size.height;
    
    CGRect visibleRect = self.view.frame;
    
    visibleRect.size.height -= keyboardSize.height;
    
    if (!CGRectContainsPoint(visibleRect, buttonOrigin)){
        
        CGPoint scrollPoint = CGPointMake(0.0, buttonOrigin.y - visibleRect.size.height + buttonHeight);
        
        [self.scrollView setContentOffset:scrollPoint animated:YES];
        
    }
    
}

- (void)keyboardWillBeHidden:(NSNotification *)notification {
    
    [self.scrollView setContentOffset:CGPointZero animated:YES];
    
}
-(void)dismissKeyboard {
    [self.txtUser resignFirstResponder];
    [self.txtPassword resignFirstResponder];
}

- (void)setPersonArray
{
    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath = [path objectAtIndex:0];
    dbPathString = [docPath stringByAppendingPathComponent:@"person.db"];
    
    sqlite3_stmt* stmt =NULL;
    int rc=0;
    rc = sqlite3_open_v2([dbPathString UTF8String], &personDB, SQLITE_OPEN_READONLY , NULL);
    
    if (SQLITE_OK != rc)
    {
        sqlite3_close(personDB);
        NSLog(@"Failed to open db connection");
    }
    else
    {
        NSString  * query = [NSString stringWithFormat:@"SELECT * from person"];
        
        rc =sqlite3_prepare_v2(personDB, [query UTF8String], -1, &stmt, NULL);
        if(rc == SQLITE_OK)
        {
            [arrayOfPerson removeAllObjects];
            while (sqlite3_step(stmt) == SQLITE_ROW) //get each row in loop
            {
                Person *person = [[Person alloc]init];
                [person setId:[NSString stringWithUTF8String:(const char *)sqlite3_column_text(stmt, 0)]];
                [person setName:[NSString stringWithUTF8String:(const char *)sqlite3_column_text(stmt, 1)]];
                [person setSurname:[NSString stringWithUTF8String:(const char *)sqlite3_column_text(stmt, 2)]];
                [person setPassword:[NSString stringWithUTF8String:(const char *)sqlite3_column_text(stmt, 3)]];
                [person setEmail:[NSString stringWithUTF8String:(const char *)sqlite3_column_text(stmt, 4)]];
                [person setPhone:[NSString stringWithUTF8String:(const char *)sqlite3_column_text(stmt, 5)]];
                [person setActvState:sqlite3_column_int(stmt, 7)];
                [arrayOfPerson addObject:person];
                
            }
            NSLog(@"Done");
            sqlite3_finalize(stmt);
        }
        else
        {
            NSLog(@"Failed to prepare statement with rc:%d",rc);
        }
        sqlite3_close(personDB);
    }
}
-(Person *)getPerson
{
    [self setPersonArray];
    Person *aPerson=nil;
    for (Person *theObject in arrayOfPerson)
    {
        // without an actual type, I still think the compiler might
        // throw a warning on this next line of code;
        // but maybe RJR III is correct and it won't warn.
        // I didn't check.
        NSString * nameOfObject = [theObject email];
        NSString * nameOfPassword = [theObject password];
        if([nameOfObject isEqualToString:self.txtUser.text] && [nameOfPassword isEqualToString:self.txtPassword.text])
        {
            aPerson = theObject;
            NSLog(@"%@",aPerson);
            return aPerson;
        }
    }
    return aPerson;
}

//Navigation bar button'u ile subview geçiş için myBarButton action ' ın implementasyonu

 -(void)buttonAction:(id)sender
 {
     signUpViewController=[[UIStoryboard storyboardWithName:@"MainStoryboard" bundle:nil] instantiateViewControllerWithIdentifier:@"SignUpViewController"];
     [self.navigationController pushViewController:signUpViewController animated:YES];
 
 }
-(void)verificationButtonAction:(id)sender
{
    if([self shouldPerformSegueWithIdentifier:@"ShowProfile" sender:sender]){
    verificationViewController=[[UIStoryboard storyboardWithName:@"MainStoryboard" bundle:nil] instantiateViewControllerWithIdentifier:@"VerificationViewController"];
    [self.navigationController pushViewController:verificationViewController animated:YES];
    NSLog(@"::::%@",self.getPerson.Id);
    verificationViewController.self.Id = self.getPerson.Id;
    verificationViewController.self.mail = self.txtUser.text;
    }
}
-(void)setupAlerts{
    [self.txtUser addRegx:REGEX_USER_NAME_LIMIT withMsg:@"User name charaters limit should be come between 10-35"];
    [self.txtUser addRegx:REGEX_USER_NAME withMsg:@"Enter a valid email address."];
    self.txtUser.validateOnResign=NO;
    
    [self.txtPassword addRegx:REGEX_PASSWORD2_LIMIT withMsg:@"Password characters limit should be come between 6-20"];
    [self.txtPassword addRegx:REGEX_PASSWORD2 withMsg:@"Password must contain alpha numeric characters."];
    
}
- (BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender   {
    
    if([identifier isEqualToString:@"ShowProfile"])
    {
        if([self.txtUser validate] & [self.txtPassword validate] ){
            return YES;
        }
    }
    return NO;
    
}
-(void)performSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    personProfileViewController=[[UIStoryboard storyboardWithName:@"MainStoryboard" bundle:nil] instantiateViewControllerWithIdentifier:@"PersonProfileVC"];
    [self.navigationController pushViewController:personProfileViewController animated:NO];
    
}
- (IBAction)signInButton:(id)sender {
    if([self shouldPerformSegueWithIdentifier:@"ShowProfile" sender:sender])
    {
        Person *aPerson = self.getPerson;
        if(aPerson!=nil){
            if(aPerson.ActvState==1){
                [self performSegueWithIdentifier:@"ShowProfile" sender:sender];
                NSLog(@"%@",aPerson.Id);
            }
            else
            {
                UIBarButtonItem *myBarButton = [[UIBarButtonItem alloc] initWithTitle:@"Verification" style:UIBarButtonItemStyleDone target:self action:@selector(verificationButtonAction:)];
                myBarButton.tag=(int)aPerson.Id;
                self.navigationItem.leftBarButtonItems = @[myBarButton];
            }
        }
        else
            NSLog(@"Kullanici Bulunamadi");
    }
}
@end
